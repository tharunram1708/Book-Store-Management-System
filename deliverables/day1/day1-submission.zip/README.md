# PageTurner Bookstore Management

Django starter project for bookstore accounts and book inventory. MySQL is the default database backend. The local SQLite switch lets you work on the project without a running MySQL server.

## Setup

1. Create and activate a virtual environment, then install dependencies:

   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install -r requirements.txt
   ```

2. Create a MySQL database named `bookstore_db` (or set `DB_NAME`). Copy `.env.example` to `.env` and set your database credentials and a private `SECRET_KEY`. Django loads these values from `.env`.

   For local development without MySQL, set `$env:DB_ENGINE='sqlite3'` before running Django commands.

3. Apply migrations and create an admin account:

   ```powershell
   python manage.py migrate
   python manage.py createsuperuser
   python manage.py runserver
   ```

   Open `http://127.0.0.1:8000/`. Add book categories in `/admin/` before creating books. Registration and book management are available in the site navigation.

## Day 1 features

- Apps: `accounts`, `books`, `categories`, `cart`, `orders`, and `dashboard`.
- Account registration, login, logout, and profile editing.
- Book list/search, detail page, and authenticated create/update/delete actions.
- Book fields include title, author, ISBN, price, description, category, stock, and cover image.
- Form validation for unique email/ISBN, ISBN length, nonnegative price/stock, and Django password rules.
- Bootstrap templates; book cover uploads are served from `media/` in development.

The `cart` and `orders` apps are registered placeholders for later project days.
