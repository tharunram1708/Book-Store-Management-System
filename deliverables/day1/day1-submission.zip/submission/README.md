# Day 1 submission: PageTurner Bookstore

The Django project root contains the working Day 1 implementation and database migrations. The screenshots below were captured from the running app using a disposable local SQLite demo catalog.

## Evidence

### Registration

![Registration page](screenshots/registration.png)

### Login

![Login page](screenshots/login.png)

### Book catalog and management actions

![Authenticated book management list](screenshots/book-management.png)

### Add a book

![Add book form](screenshots/book-add.png)

### Book details with edit and delete actions

![Book detail page](screenshots/book-detail.png)

### Edit book

![Edit book form](screenshots/book-edit.png)

## Included in the project

- Registration, login, logout, and profile editing.
- Book list/search, details, add, edit, and delete flows.
- Account profile, category, and book models with migrations.
- MySQL configuration via `.env`; SQLite is available for local demonstrations.
- Bootstrap templates and book cover uploads.

The screenshot catalog uses local demo records. They are not committed as production data. Start the app using the setup steps in the root `README.md`.
