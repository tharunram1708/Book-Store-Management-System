from django import forms
from .models import Book

class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = ("title", "author", "isbn", "price", "description", "category", "stock", "cover_image")
        widgets = {"description": forms.Textarea(attrs={"rows": 5}),
                   "price": forms.NumberInput(attrs={"step": "0.01", "min": "0"}),
                   "stock": forms.NumberInput(attrs={"min": "0"})}
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs["class"] = "form-select" if field.widget.__class__.__name__ == "Select" else "form-control"
    def clean_isbn(self):
        isbn = "".join(c for c in self.cleaned_data["isbn"] if c.isdigit() or c.upper() == "X").upper()
        if len(isbn) not in (10, 13):
            raise forms.ValidationError("Enter a valid 10 or 13 character ISBN.")
        query = Book.objects.filter(isbn=isbn)
        if self.instance.pk:
            query = query.exclude(pk=self.instance.pk)
        if query.exists():
            raise forms.ValidationError("A book with this ISBN already exists.")
        return isbn
    def clean_price(self):
        price = self.cleaned_data["price"]
        if price < 0:
            raise forms.ValidationError("Price cannot be negative.")
        return price
