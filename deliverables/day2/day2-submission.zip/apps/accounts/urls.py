from django.contrib.auth import views as auth_views
from django.urls import path
from .forms import BookstoreAuthenticationForm
from . import views

urlpatterns = [path("register/", views.register, name="register"),
               path("login/", auth_views.LoginView.as_view(template_name="registration/login.html", authentication_form=BookstoreAuthenticationForm), name="login"),
               path("logout/", auth_views.LogoutView.as_view(), name="logout"),
               path("profile/", views.profile, name="profile")]
